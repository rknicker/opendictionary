const dictionary = [
  {
    name: "Apple",
    wordVersion: "1.1.1",
    slug: "apple-1-1-1",
    description:
      "A round fruit with red or green skin and a firm white inside.",
    telegramPost: "5",
    version: "1.0",
  },
  {
    name: "Apple",
    wordVersion: "1.1.2",
    slug: "apple-1-1-2",
    description:
      "A round fruit with red or green skin and a firm white inside.",
    telegramPost: "6",
    version: "1.0",
  },
  {
    name: "Apple",
    wordVersion: "1.1.3",
    slug: "apple-1-1-3",
    description:
      "A round fruit with red or green skin and a firm white inside.",
    telegramPost: "7",
    version: "1.0",
  },
  {
    name: "United States",
    wordVersion: "1.1.1",
    slug: "united-states-1-1-1",
    description:
      "A Nation that borders with Canada to the north and Mexico to the south, with coasts on the Atlantic and the Pacific.",
    telegramPost: "8",
    version: "1.0",
  },
  {
    name: "an apple a day",
    wordVersion: "1.1.1",
    slug: "an-apple-a-day-4-2-3",
    description:
      "Drs orders. An apple a day keeps the doctors at bay.",
    telegramPost: "9",
    version: "1.0",
  },
];

export default dictionary;
