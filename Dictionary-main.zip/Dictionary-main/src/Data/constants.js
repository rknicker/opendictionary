export const telegramChannelName = "opendictionary1";
